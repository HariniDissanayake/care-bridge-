import { useState } from "react"
export default function App() {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState([])

  const [loading, setLoading] = useState(false)

  const sendMessage = async () => {
    if (message.trim() === "") return

    const userMsg = message
    setMessages(prev => [...prev, { text: userMsg, sender: "user" }])
    setMessage("")
    setLoading(true)

    try {
      const res = await fetch("http://localhost:5000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg })
      })

      if (!res.ok) throw new Error("Server error")

      const data = await res.json()
      setMessages(prev => [...prev, { text: data.reply, sender: "ai" }])
    } catch (err) {
      setMessages(prev => [
        ...prev,
        { text: "Sorry, I couldn't connect right now. Please try again.", sender: "ai" }
      ])
    } finally {
      setLoading(false)
    }
  }

  return (

    <div className="h-screen flex bg-gray-100">

      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg p-6">

        <h1 className="text-2xl font-bold text-teal-700">
          CareBridge
        </h1>

        <p className="mt-2 text-gray-500">
          AI Support Chat
        </p>

        <div className="mt-10 space-y-3">

          <button className="w-full p-3 rounded bg-teal-100">
            😊 Happy
          </button>

          <button className="w-full p-3 rounded bg-teal-100">
            😔 Sad
          </button>

          <button className="w-full p-3 rounded bg-teal-100">
            😰 Anxious
          </button>

          <button className="w-full p-3 rounded bg-teal-100">
            😵 Overwhelmed
          </button>

        </div>

      </div>

      {/* Main Chat */}
      <div className="flex-1 flex flex-col">

        {/* Header */}
        <div className="bg-white p-5 shadow">

          <h2 className="text-xl font-semibold">
            Aria — AI Companion
          </h2>

        </div>

        {/* Chat Area */}
        <div className="flex-1 p-8 bg-slate-100 space-y-3 overflow-y-auto">

          {messages.length === 0 && (
            <div className="bg-white rounded-xl p-4 w-fit shadow">
              Hello! How are you feeling today?
            </div>
          )}

          {messages.map((msg, index) => (
            <div
              key={index}
              className={`p-3 rounded-xl w-fit max-w-xs ${
                msg.sender === "user"
                  ? "bg-teal-100 ml-auto"
                  : "bg-white"
              }`}
            >     
              {msg.text}
            </div>
          ))}

          {loading && (
            <div className="bg-white rounded-xl p-4 w-fit shadow text-gray-400 italic">
              Aria is typing...
            </div>
          )}

        </div>

        {/* Input */}
        <div className="bg-white p-4 flex gap-3">

          <input 
            type="text"
            placeholder="Share what's on your mind..."
            className="flex-1 border rounded-lg p-3"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          />

          <button
            onClick={sendMessage}
            disabled={loading}
            className="bg-teal-600 text-white px-6 rounded-lg disabled:opacity-50"
          >
            Send
          </button>

        </div>

      </div>

    </div>
  )
}