import express from "express"
import cors from "cors"
import dotenv from "dotenv"
import axios from "axios"

dotenv.config()
const app = express()
app.use(cors())
app.use(express.json())

app.post("/chat", async (req, res) => {
  try {
    const userMessage = req.body.message

    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        systemInstruction: {
          parts: [{ text: "You are Aria, a warm, emotionally supportive companion for CareBridge users. Keep replies short, kind, and caring." }]
        },
        contents: [
          { parts: [{ text: userMessage }] }
        ]
      },
      { headers: { "Content-Type": "application/json" } }
    )

    const reply = response.data.candidates[0].content.parts[0].text
    res.json({ reply })
  } catch (error) {
    console.error(error.response?.data || error.message)
    res.status(500).json({ error: "AI error" })
  }
})

app.listen(5000, () => {
  console.log("Server running on http://localhost:5000")
})